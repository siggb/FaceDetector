<script> 
var qipSizeReq = null;
var qipFileURL = "";
var qipTimer = 0;
var qipBlock = 1;
var qipBlocksOn = true;

function qipPIAnimate ()
{
block = document.getElementById('qipb' + qipBlock);
if (!block) { return; }
if (qipBlocksOn) { block.style.backgroundColor = "<WEBFILES_VAR Hilite1>"; }
else { block.style.backgroundColor = "<WEBFILES_VAR Hilite2>"; }
qipBlock++;
if (qipBlock > 7) {
	qipBlock = 1;
	qipBlocksOn = !qipBlocksOn;
	}
qipTimer=setTimeout("qipPIAnimate()",100);
}

function qipOpen() 
{
if (qipSizeReq.readyState == 4) {
	if (qipSizeReq.status == 200) {
		response=qipSizeReq.responseXML.documentElement;
		qipSizeReq=null;
		qipWidth=response.getElementsByTagName('width')[0].firstChild.data;
		qipHeight=response.getElementsByTagName('height')[0].firstChild.data;
		qipDispType=response.getElementsByTagName('displayType')[0].firstChild.data;
		if (qipWidth == 0) {
			document.getElementById("quipBox").style.width = "280px";
			document.getElementById("quipBox").style.height = "58px";
			document.getElementById("qipContent").innerHTML = "<p style='font-size:14px;'>No image preview is available for this file.</p>";
			}
		else {
			document.getElementById("quipBox").style.width = qipWidth + "px";
			if (qipDispType == "video") {
				ht = parseInt(qipHeight)+16;
				document.getElementById("quipBox").style.height = ht + "px";
				vid = document.getElementById('qipContent');
				tempFileURL=qipFileURL.replace(/\"/g,'%22');
				vid.innerHTML = "<OBJECT CLASSID=\"clsid:02BF25D5-8C17-4B23-BC80-D3488ABDDC6B\" WIDTH=\"" + qipWidth + "\" HEIGHT=\"" + ht + "\" CODEBASE=\"http://www.apple.com/qtactivex/qtplugin.cab\"><PARAM name=\"SRC\" VALUE=\"" + tempFileURL + "\"><PARAM name=\"AUTOPLAY\" VALUE=\"true\"><PARAM name=\"CONTROLLER\" VALUE=\"true\"><PARAM name=\"KIOSKMODE\" VALUE=\"true\"><EMBED SRC=\"" + tempFileURL + "\" WIDTH=\"" + qipWidth + "\" HEIGHT=\"" + ht + "\" AUTOPLAY=\"true\" CONTROLLER=\"true\" KIOSKMODE=\"true\" PLUGINSPAGE=\"http://www.apple.com/quicktime/download/\"></EMBED></OBJECT>";
				}
			else {
				tempFileURL=qipFileURL.replace(/\'/g,'%27');
				document.getElementById("quipBox").style.height = qipHeight + "px";
				document.getElementById("qipContent").innerHTML = "<img src='" + tempFileURL + ".jpg?qip'>";
				}
			}
		}
	else {
		alert ("The image could not be loaded.");
		}
	}
}

function qipClose()
{
document.getElementById("qipContent").innerHTML = "";
document.getElementById("qipDisplay").style.visibility="hidden";
}

function qipDisplay(fileName)
{
qipFileURL = "<WEBFILES_THISURL>" + encodeURIComponent(fnDecode (fileName));
document.getElementById("floater").innerHTML = "";
document.getElementById("quipBox").style.width = "200px";
document.getElementById("quipBox").style.height = "80px";
document.getElementById("qipDisplay").style.visibility="visible";
document.getElementById("qipContent").innerHTML = "<p>Loading ...</p><table id='qipPI'><tr><td class='qipb' id='qipb1'>&nbsp</td><td class='qipb' id='qipb2'>&nbsp</td><td class='qipb' id='qipb3'>&nbsp</td><td class='qipb' id='qipb4'>&nbsp</td><td class='qipb' id='qipb5'>&nbsp</td><td class='qipb' id='qipb6'>&nbsp</td><td class='qipb' id='qipb7'>&nbsp</td></tr></table>";
qipBlock = 1;
qipBlocksOn = true;
qipPIAnimate ();
if (window.ActiveXObject) qipSizeReq=new ActiveXObject("Microsoft.XMLHTTP");
else qipSizeReq=new XMLHttpRequest();
qipSizeReq.onreadystatechange=qipOpen;
qipSizeReq.open("GET", qipFileURL + ".xml?qip", true);
qipSizeReq.send(null);
}
</script> 
