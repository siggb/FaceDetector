// General

var autoSelect="";
var CurrentHelp="";

function DispBox (ftitle,loadName)
{
window.scrollTo(0,0);
document.getElementById("formdisplay").style.visibility="visible";
document.getElementById("formtitle").innerHTML=ftitle;
LoadForm ("/RAPR/" + loadName + ".html");
}

function CancelBox()
{
if (document.getElementById("UCFRevertOnCancel")) TriggerServerFunction ("/RAPR/TriggerServerFunction.html?UploadCenterRevert");
window.scrollTo(0,0);
document.getElementById("formdisplay").style.visibility="hidden";
if (selectedItemType == "WebGeneral") selectedItemType = "WebAppearance";
if (selectedItemType == "AdminNotices") selectedItemType = "Notices";
}

function LoadForm (url)
{
document.getElementById("formspace").innerHTML = "<p>&nbsp;</p><p>Loading ...</p><p>&nbsp;</p>";
if (window.XMLHttpRequest) {
  req = new XMLHttpRequest();
  }
else if (window.ActiveXObject) {
  req = new ActiveXObject("Microsoft.XMLHTTP");
  }
if (req != undefined) {
  req.onreadystatechange = function() { FormDone(url); };
  req.open("GET", url, true);
  req.send("");
  }
}  

function FormDone (url)
{
if (req.readyState == 4) {
  if (req.status == 200) {
    if (req.responseText == "login") window.location = "/";
    document.getElementById("formspace").innerHTML = req.responseText;
    c = document.getElementById("BackgroundColor");
	if (c) {
      new jscolor.color(document.getElementById('BackgroundColor'), {});
      new jscolor.color(document.getElementById('Highlight1Color'), {});
      new jscolor.color(document.getElementById('Highlight2Color'), {});
      new jscolor.color(document.getElementById('Highlight3Color'), {});
      new jscolor.color(document.getElementById('TextColor'), {});
      new jscolor.color(document.getElementById('BoldColor'), {});
      new jscolor.color(document.getElementById('LinkColor'), {});
      new jscolor.color(document.getElementById('RolloverColor'), {});
    }
    
    // BUG? Should any of these special case adjustments be removed?
    
    selecttype = document.getElementById("selectdetail");
    if (selecttype) document.getElementById('formspace').style.overflow="visible";
    else document.getElementById('formspace').style.overflow="auto";

	is_ucf = document.getElementById("UCFTable");
	if (is_ucf) SetUCFormWidth ();

    activity = document.getElementById('activitydetail');
    if (activity) LoadActivity();
    SetBoxHeight();
    document.getElementById("formspace").scrollTop = 0;
    usermenu=document.getElementById('UserMenu');
    if (usermenu) usermenu.focus();
    autoSelect="";
    
    forceHeight = document.getElementById("wHeight");
    if (forceHeight) document.getElementById("editbox").style.height = forceHeight.value;
  }
  else {
    document.getElementById("formspace").innerHTML="Failed to load administration form.";
    }
  }
}

function SetWorkspaceHeight ()
{
var myHeight = 400;

if (typeof(window.innerHeight) == 'number') myHeight = window.innerHeight;
else
if (document.documentElement && document.documentElement.clientHeight) myHeight = document.documentElement.clientHeight;
else if (document.body && document.body.clientHeight) myHeight = document.body.clientHeight;

if (myHeight > 844) myHeight = 844;
if (myHeight < 354) myHeight = 354;

document.getElementById("workspace").style.height = (myHeight - 140) + "px";
document.getElementById("menu").style.height = (myHeight - 140) + "px";
document.getElementById("itemselect").style.height = (myHeight - 140) + "px";
list = document.getElementById("is_selection");
if (list) {
	tbmarg = 170;
	if (document.getElementById("WebGeneralButton").style.display == "block")
		tbmarg += document.getElementById("WebGeneralButton").offsetHeight + 30;
	if (document.getElementById("EventTriggersButton").style.display == "block")
		tbmarg += document.getElementById("EventTriggersButton").offsetHeight + 30;
	list.size = ((myHeight - tbmarg) / 17);
	list.style.display='none';
	list.style.display='inline';
	}
}

function SetBoxHeight ()
{
var myHeight = 500;

if (typeof(window.innerHeight) == 'number') myHeight = window.innerHeight;
else
if (document.documentElement && document.documentElement.clientHeight) myHeight = document.documentElement.clientHeight;
else if (document.body && document.body.clientHeight) myHeight = document.body.clientHeight;

document.getElementById("formspace").style.height = (myHeight - 140) + "px";
detailbox = document.getElementById("selectdetail");
if (detailbox) detailbox.style.height = (myHeight - 140) + "px";
listbox = document.getElementById("selectlist");
if (listbox) {
	lbm = ((myHeight - 540) / 2);
	if (lbm < 12) lbm = 12;
	listbox.style.marginTop = lbm + "px";
	}
}

// Common functions used by multiple settings forms.

function SubmitForm ()
{
document.getElementById("SettingsForm").submit();
}

function SubmitResult (errmess)
{
window.scrollTo(0,0);
if (errmess == "OK") {
	document.getElementById("changessaved").style.visibility="visible";
	}
else if (errmess == "NONE") {
	CancelBox();
	}
else {
    document.getElementById("errormessage").innerHTML="<p>"+errmess+"</p>";
	document.getElementById("errorreport").style.visibility="visible";
	}
}

function CloseStatus()
{
var box;

window.scrollTo(0,0);
box = document.getElementById("formdisplay");
if (box) box.style.visibility="hidden";
box = document.getElementById("changessaved");
if (box) box.style.visibility="hidden";
box = document.getElementById("errorreport");
if (box) box.style.visibility="hidden";
}

function MailTest ()
{
var UseTLS = "NO";
var UseEHLO = "NO";
if (document.getElementById("SMTPUseTLS").checked) UseTLS = "YES";
if (document.getElementById("SMTPUseEHLO").checked) UseEHLO = "YES";
parms = document.getElementById("SMTPServer").value + ";;" + document.getElementById("SMTPPort").value + ";;" + encodeURI(document.getElementById("SMTPUsername").value) + ";;" + encodeURI(document.getElementById("SMTPPassword").value) + ";;" + encodeURI(document.getElementById("SMTPAdminEMail").value) + ";;" + UseTLS + ";;" + UseEHLO;
TriggerServerFunction ("/RAPR/TriggerServerFunction.html?SendTestMail;;" + parms);
}

// Selection Processing Functions

var selectedItemType = "";
var selectedItem = "";

function OpenItemSelect (items)
{
list = document.getElementById("is_selection");
list.options.length = 0;

selectedItemType = items;

document.getElementById("WebGeneralButton").style.display="none";
document.getElementById("EventTriggersButton").style.display="none";

switch (items) {
	case "WebAppearance":
		document.getElementById("is_title").innerHTML = "Web Appearance Settings";
		document.getElementById("is_edit").innerHTML = "Edit Settings";
		document.getElementById("is_create").style.display="none";
		document.getElementById("is_delete").style.display="none";
		document.getElementById("is_create").innerHTML = "Create Domain";
		document.getElementById("is_delete").innerHTML = "Delete Domain";
		document.getElementById("WebGeneralButton").style.display="block";
		break;
	case "Users":
		document.getElementById("is_title").innerHTML = "Define Users";
		document.getElementById("is_edit").innerHTML = "Edit Account";
		document.getElementById("is_create").style.display="block";
		document.getElementById("is_delete").style.display="block";
		document.getElementById("is_create").innerHTML = "Create New Account";
		document.getElementById("is_delete").innerHTML = "Delete Account";
		break;
	case "Notices":
		document.getElementById("is_title").innerHTML = "Event Notices";
		document.getElementById("is_edit").innerHTML = "Edit Notice";
		document.getElementById("is_create").style.display="block";
		document.getElementById("is_delete").style.display="block";
		document.getElementById("is_create").innerHTML = "Create New Notice";
		document.getElementById("is_delete").innerHTML = "Delete Notice";
		document.getElementById("EventTriggersButton").style.display="block";
		break;
	case "FolderSets":
		document.getElementById("is_title").innerHTML = "Folder Sets";
		document.getElementById("is_edit").innerHTML = "Edit Set";
		document.getElementById("is_create").style.display="block";
		document.getElementById("is_delete").style.display="block";
		document.getElementById("is_create").innerHTML = "Create New Folder Set";
		document.getElementById("is_delete").innerHTML = "Delete Folder Set";
		break;
	case "Forms":
		document.getElementById("is_title").innerHTML = "Define Upload Center Forms";
		document.getElementById("is_edit").innerHTML = "Edit Form";
		document.getElementById("is_create").style.display="block";
		document.getElementById("is_delete").style.display="block";
		document.getElementById("is_create").innerHTML = "Create New Form";
		document.getElementById("is_delete").innerHTML = "Delete Form";
		break;
	case "Types":
		document.getElementById("is_title").innerHTML = "Define File Types";
		document.getElementById("is_edit").innerHTML = "Edit File Type";
		document.getElementById("is_create").style.display="block";
		document.getElementById("is_delete").style.display="block";
		document.getElementById("is_create").innerHTML = "Create New Type";
		document.getElementById("is_delete").innerHTML = "Delete Type";
		break;
	}

FetchItemList (items);
document.getElementById("itemselect").style.visibility="visible";
SetWorkspaceHeight ();
}

function FetchItemList (listtype)
{
if (window.XMLHttpRequest) {
  req = new XMLHttpRequest();
  }
else if (window.ActiveXObject) {
  req = new ActiveXObject("Microsoft.XMLHTTP");
  }
if (req != undefined) {
  req.onreadystatechange = function() { FetchItemDone(listtype); };
  req.open("GET", "/RAPR/GetItemList-" + listtype + ".html", true);
  req.send("");
  }
}  

function FetchItemDone (listtype)
{
list = document.getElementById("is_selection");
list.options.length = 0;

if (req.readyState == 4) {
	if (req.status == 200) {
		if (req.responseText != "-") {
			var results = req.responseText.split("\t");
			for (i = 0; i < results.length; i++) {
				if (results[i] == selectedItem)
					list.options[i]=new Option(results[i], results[i], false, true);
				else
					list.options[i]=new Option(results[i], results[i], false, false);
				}
			}
		}
	else {
		alert ("Failed to execute server function.");
		}

	selectedItem = "";
	}
}

function OpenCreateBox()
{
ConfirmSelectedItemType ();

document.getElementById("itemname").value = "";
document.getElementById("password").value = "";

list = document.getElementById("is_selection");
useselasdef = document.getElementById("useselectedasdefault");
if (useselasdef) {
	if (list.selectedIndex < 0) useselasdef.style.display="none";
	else useselasdef.style.display="inline";
	}

if (selectedItemType == "Users") document.getElementById("passwordprompt").style.display="table-row";
else document.getElementById("passwordprompt").style.display="none";

eventtype = document.getElementById("eventnoticetype");
if (eventtype) {
	if (selectedItemType == "Notices") document.getElementById("eventnoticetype").style.display="table-row";
	else document.getElementById("eventnoticetype").style.display="none";
	}

switch (selectedItemType) {
	case "Web":
		if ((list.selectedIndex == 0) && (useselasdef)) useselasdef.style.display="none";
		document.getElementById("itemnameprompt").innerHTML="Domain Name:";
		document.getElementById("createtitle").innerHTML="Create New Domain";
		document.getElementById("createacceptbutton").value="Create Domain";
		break;
	case "Users":
		document.getElementById("itemnameprompt").innerHTML="Username:";
		document.getElementById("createtitle").innerHTML="Create New User Account";
		document.getElementById("createacceptbutton").value="Create Account";
		break;
	case "Notices":
		document.getElementById("itemnameprompt").innerHTML="Event Notice Name:";
		document.getElementById("createtitle").innerHTML="Create New Event Notice";
		document.getElementById("createacceptbutton").value="Create Notice";
		break;
	case "FolderSets":
		document.getElementById("itemnameprompt").innerHTML="Folder Set Name:";
		document.getElementById("createtitle").innerHTML="Create New Folder Set";
		document.getElementById("createacceptbutton").value="Create Folder Set";
		break;
	case "Forms":
		document.getElementById("itemnameprompt").innerHTML="Form Name:";
		document.getElementById("createtitle").innerHTML="Create New Form";
		document.getElementById("createacceptbutton").value="Create Form";
		useselasdef.style.display="none";
		break;
	case "Types":
		document.getElementById("itemnameprompt").innerHTML="File Type Suffix:";
		document.getElementById("createtitle").innerHTML="Create New File Type";
		document.getElementById("createacceptbutton").value="Create Type";
		break;
}

window.scrollTo(0,0);
document.getElementById("createnew").style.visibility="visible";
document.getElementById("itemname").focus();
}

function CloseCreateBox()
{
window.scrollTo(0,0);
document.getElementById("createnew").style.visibility="hidden";
}

function OpenDeleteBox()
{
ConfirmSelectedItemType ();

switch (selectedItemType) {
	case "Web":
		typedesc = "domain";
		deltitle = "Delete Domain";
		buttonlabel = "Delete Domain";
		break;
	case "Users":
		typedesc = "user account";
		deltitle = "Delete User Account";
		buttonlabel = "Delete Account";
		break;
	case "Notices":
		typedesc = "notice";
		deltitle = "Delete Event Notice";
		buttonlabel = "Delete Notice";
		break;
	case "FolderSets":
		typedesc = "folder set";
		deltitle = "Delete Folder Set";
		buttonlabel = "Delete Folder Set";
		break;
	case "Forms":
		typedesc = "form";
		deltitle = "Delete Upload Center Form";
		buttonlabel = "Delete Form";
		break;
	case "Types":
		typedesc = "file type";
		deltitle = "Delete File Type";
		buttonlabel = "Delete File Type";
		break;
	}
	
list = document.getElementById("is_selection");
if (list.selectedIndex < 0) {
  alert ("Please first select a " + typedesc + " to delete.");
  return;
  }

itemSel = list.options[list.selectedIndex].value;
if ((selectedItemType == "Users") && (itemSel == "ANONYMOUS")) {
  alert ("The 'Anonymous' user account is special and can't be deleted.  To disallow anonymous access, disable the 'Permit Login' privilege.");
  return;
  }

document.getElementById("deletetitle").innerHTML = deltitle;
document.getElementById("deletenote").innerHTML = "Are you sure you would like to delete this " + typedesc + "?";
document.getElementById("deleteitem").innerHTML = itemSel;
document.getElementById("deletebutton").value = buttonlabel;
window.scrollTo(0,0);
document.getElementById("confirmdelete").style.visibility="visible";
}

function AcceptDeleteBox()
{
switch (selectedItemType) {
	case "Web":
		typedesc = "domain";
		delfunc = "DeleteDomain";
		break;
	case "Users":
		typedesc = "user account";
		delfunc = "DeleteUserAccount";
		break;
	case "Notices":
		typedesc = "notice";
		delfunc = "DeleteEventNotice";
		break;
	case "FolderSets":
		typedesc = "folder set";
		delfunc = "DeleteFolderSet";
		break;
	case "Forms":
		typedesc = "form";
		delfunc = "DeleteForm";
		break;
	case "Types":
		typedesc = "file type";
		delfunc = "DeleteFileType";
		break;
	}

list = document.getElementById("is_selection");
if (list.selectedIndex < 0) {
  alert ("No " + typedesc + " was selected to delete.");
  return;
  }
delItem = list.options[list.selectedIndex].value;

TriggerServerFunction ("/RAPR/TriggerServerFunction.html?" + delfunc + ";;" + encodeURI(delItem));
}

function CloseDeleteBox()
{
window.scrollTo(0,0);
document.getElementById("confirmdelete").style.visibility="hidden";
}

function AcceptCreateBox()
{
ConfirmSelectedItemType ();

newItemName = document.getElementById("itemname").value;

dupItem = "";
dupOpt = document.getElementById("duplicateselected");
if ((dupOpt) && (dupOpt.checked)) {
	list = document.getElementById("is_selection");
	if (list.selectedIndex >= 0) dupItem = list.options[list.selectedIndex].value;
	}

switch (selectedItemType) {
	case "Web":
		tfunction = "CreateDomain";
		requiredtype = "domain name";
		parms = encodeURI(newItemName) + ";;" + dupItem;
		break;
	case "Users":
		tfunction = "CreateUserAccount";
		requiredtype = "user account name";
		parms = encodeURI(newItemName) + ";;" + encodeURIComponent(document.getElementById("password").value) + ";;" + dupItem;
		break;
	case "Notices":
		tfunction = "CreateEventNotice";
		requiredtype = "notice name";
		parms = encodeURI(newItemName) + ";;" + document.getElementById("newnoticetype").selectedIndex + ";;" + dupItem;
		break;
	case "FolderSets":
		tfunction = "CreateFolderSet";
		requiredtype = "folder set name";
		parms = encodeURI(newItemName) + ";;" + dupItem;
		break;
	case "Forms":
		tfunction = "CreateUploadCenterForm";
		requiredtype = "form name";
		parms = encodeURI(newItemName) + ";;" + dupItem;
		break;
	case "Types":
		tfunction = "CreateFileType";
		requiredtype = "file type suffix";
		parms = encodeURI(newItemName) + ";;" + dupItem;
		break;
	}

if (newItemName.length < 1) {
	alert ("Please supply a " + requiredtype + ".");
	return;
	}

selectedItem = newItemName;
TriggerServerFunction ("/RAPR/TriggerServerFunction.html?" + tfunction + ";;" + parms);
}

function TriggerServerFunction (url)
{
if (window.XMLHttpRequest) {
	req = new XMLHttpRequest();
	}
else if (window.ActiveXObject) {
	req = new ActiveXObject("Microsoft.XMLHTTP");
	}
if (req != undefined) {
	req.onreadystatechange = function() { ServerFunctionDone(url); };
	req.open("GET", url, true);
	req.send("");
	}
}  

function ServerFunctionDone (url)
{
if (req.readyState == 4) {
	if (req.status == 200) {
		if (req.responseText.substr (0,4) == "Err:") {
			alert (req.responseText.substr (4));
			}
		else {
			if (req.responseText.substr (0,3) == "OK:") alert (req.responseText.substr (3));
			ConfirmSelectedItemType ();
			FetchItemList (selectedItemType);
			}
		}
  	else {
		alert ("Failed to execute server function.");
		}
	}
window.scrollTo(0,0);
document.getElementById("createnew").style.visibility="hidden";
document.getElementById("confirmdelete").style.visibility="hidden";
}

function OpenEditBox (type)
{
itemSel = "";
itemDesc = "";

if (type != "") selectedItemType = type;

ConfirmSelectedItemType ();

switch (selectedItemType) {
	case "Network":
		ftitle = "Network Settings";
		itemSel = "-";
		itemDesc = "-";
		loadName = "NetworkSettings";
		boxWidth = "640px";
		boxHeight = "auto";
		break;
	case "FTP":
		ftitle = "FTP Settings";
		itemSel = "-";
		itemDesc = "-";
		loadName = "FTPSettings";
		boxWidth = "640px";
		boxHeight = "auto";
		break;
	case "Web":
	case "WebAppearance":
		ftitle = "Web Settings";
		itemDesc = "domain";
		loadName = "WebSettings";
		boxWidth = "640px";
		boxHeight = "auto";
		break;
	case "WebGeneral":
		ftitle = "General Web Settings";
		itemSel = "+";
		itemDesc = "-";
		loadName = "WebGeneral";
		boxWidth = "640px";
		boxHeight = "auto";
		break;
	case "Users":
		ftitle = "Define Users";
		itemDesc = "user account";
		loadName = "DefineUsers";
		boxWidth = "560px";
		boxHeight = "auto";
		break;
	case "Notices":
		ftitle = "Event Notices";
		itemDesc = "event notice";
		loadName = "EventNotices";
		boxWidth = "560px";
		boxHeight = "auto";
		break;
	case "FolderSets":
		ftitle = "Folder Sets";
		itemDesc = "folder sets";
		loadName = "FolderSets";
		boxWidth = "560px";
		boxHeight = "auto";
		break;
	case "AdminNotices":
		ftitle = "Administrative Notices";
		itemSel = "+";
		itemDesc = "-";
		loadName = "AdminNotices";
		boxWidth = "540px";
		boxHeight = "400px";
		break;
	case "Forms":
		ftitle = "Upload Center Forms";
		itemDesc = "upload center form";
		loadName = "UploadCenterForms";
		boxWidth = "500px";
		boxHeight = "auto";
		break;
	case "Types":
		ftitle = "File Types";
		itemDesc = "file type";
		loadName = "FileTypes";
		boxWidth = "380px";
		boxHeight = "512px";
		break;
	case "Blocks":
		ftitle = "Blocked Clients";
		itemSel = "-";
		itemDesc = "-";
		loadName = "BlockedClients";
		boxWidth = "640px";
		boxHeight = "470px";
		break;
	case "Stats":
		ftitle = "Server Activity";
		itemSel = "-";
		itemDesc = "-";
		loadName = "ActivityMonitor";
		boxWidth = "720px";
		boxHeight = "540px";
		break;
	}

CurrentHelp = loadName;

savespot = document.getElementById("savebutton");
if (savespot) {
	if (selectedItemType == "Stats")
		savespot.innerHTML = "<img src=\"/WFMAdminRefresh.png\" onclick=\"javascript:LoadActivity();\">";
	else
		savespot.innerHTML = "<img src=\"/WFMAdminSave.png\" onclick=\"javascript:SubmitForm();\">";
	}

if (itemSel == "+") { }
else if (itemSel == "-") {
	document.getElementById("itemselect").style.visibility="hidden";
	}
else {
	list = document.getElementById("is_selection");
	if (list.selectedIndex < 0) {
		alert ("Please first select a " + itemDesc + " to edit.");
		return;
		}
	itemSel = list.options[list.selectedIndex].value;
	}

window.scrollTo(0,0);
document.getElementById("editbox").style.width = boxWidth;
document.getElementById("editbox").style.height = boxHeight;
document.getElementById("formdisplay").style.visibility="visible";
document.getElementById("formtitle").innerHTML=ftitle;

if (itemSel == "-")
  LoadForm ("/RAPR/" + loadName + ".html");
else
  LoadForm ("/RAPR/" + loadName + ".html?" + encodeURI(itemSel));
}

function EditComplete (result)
{
if (result == "OK") {
	CancelBox();
	}
else {
	alert (result);
	}
}

function ConfirmSelectedItemType ()
{
if ((selectedItemType) && (selectedItemType != "")) return;
spec = document.getElementById("itemType");
if (spec) selectedItemType = spec.value;
else selectedItemType = "";
}

function VerifyAlphanumeric (stringName)
{
if (newFieldName == "") {
	alert ("Please supply a " + stringName + ".");
	return false;
	}
var anre = /^[A-Za-z0-9]+$/;
if (!anre.test(newFieldName)) {
	alert ("A " + stringName + " may contain only letters and numbers.  The " + stringName + " is not seen by end users, and is used only to define it's identity in Rumpus.");
	return false;
	}
return true;
}

// Functions to Upload Center Forms processing

function TriggerUCFunction (url)
{
if (window.XMLHttpRequest) {
	req = new XMLHttpRequest();
	}
else if (window.ActiveXObject) {
	req = new ActiveXObject("Microsoft.XMLHTTP");
	}
if (req != undefined) {
	req.onreadystatechange = function() { UCFunctionDone(url); };
	req.open("GET", url, true);
	req.send("");
	}
}  

function UCFunctionDone (url)
{
itemSel = document.getElementById("FormName").value;
if (req.readyState == 4) {
	if (req.status == 200) {
		if (req.responseText.substr (0,4) == "Err:") {
			alert (req.responseText);
			}
		else {
			LoadForm ("/RAPR/UploadCenterForms.html?" + itemSel);
			}
		}
  	else {
		alert ("Failed to execute server function.");
		}
	}
window.scrollTo(0,0);
document.getElementById("addfield").style.visibility="hidden";
}

function AddFieldDialog ()
{
document.getElementById("addfield").style.visibility="visible";
}

function AddUploadField ()
{
newFieldName = document.getElementById("NewName").value;
if (!VerifyAlphanumeric ("field name")) return;
parms = document.getElementById("FormName").value + ";;" + newFieldName + ";;" + (document.getElementById("NewType").selectedIndex + 1) + ";;";
TriggerUCFunction ("/RAPR/TriggerServerFunction.html?AddNewField;;" + parms);
}

function EditFieldDialog (field)
{
parms = document.getElementById("FormName").value + ";;" + field;

if (window.XMLHttpRequest) {
	req = new XMLHttpRequest();
	}
else if (window.ActiveXObject) {
	req = new ActiveXObject("Microsoft.XMLHTTP");
	}
if (req != undefined) {
	req.onreadystatechange = function() { EditFieldFormDone(field); };
	req.open("GET", "/RAPR/TriggerServerFunction.html?GetFieldEditForm;;" + parms, true);
	req.send("");
	}
document.getElementById("fieldeditheader").innerHTML = "Edit Field '" + field + "'";
document.getElementById("fieldedit").style.visibility="visible";
}  

function EditFieldFormDone (field)
{
if (req.readyState == 4) {
	if (req.status == 200) {
		document.getElementById("fieldeditbody").innerHTML = req.responseText;
		}
	else {
		document.getElementById("fieldeditbody").innerHTML="Failed to load edit field form.";
		}
	}
}

function SubmitFieldEdit ()
{
document.getElementById("FieldEditForm").submit();
}

function UploadCenterResult (result)
{
document.getElementById("fieldedit").style.visibility="hidden";
OpenEditBox ("");
}

function MoveFormField (fieldnum)
{
formname = document.getElementById("FormName").value;
TriggerUCFunction ("/RAPR/TriggerServerFunction.html?MoveField;;" + formname + ";;" + fieldnum);
}

function DelFieldDialog (field)
{
document.getElementById("delfieldname").innerHTML=field;
document.getElementById("delField").value=field;
document.getElementById("deletefield").style.visibility="visible";
}

function DeleteUploadField ()
{
formname = document.getElementById("FormName").value;
fieldname = document.getElementById("delField").value;
TriggerUCFunction ("/RAPR/TriggerServerFunction.html?DeleteUploadFormField;;" + formname + ";;" + fieldname);
}

function CancelUCBox ()
{
document.getElementById("deletefield").style.visibility="hidden";
document.getElementById("addfield").style.visibility="hidden";
document.getElementById("fieldedit").style.visibility="hidden";
}

function SaveWidthStyle ()
{
formname = document.getElementById("FormName").value;
fWidth = document.getElementById("FormWidth").value;
fStyle = document.getElementById("FormStyle").selectedIndex + 1;
fPosn = document.getElementById("FormPosition").selectedIndex + 1;
if (document.getElementById("FormBoldReqs").checked) fBold = "Yes";
else fBold = "No";
TriggerUCFunction ("/RAPR/TriggerServerFunction.html?SaveWidthAndStyle;;" + formname + ";;" + fWidth + ";;" + fStyle + ";;" + fPosn + ";;" + fBold);
}

function SetUCFormWidth ()
{
fWidth = document.getElementById("FormWidth").value;
if (fWidth == "default") {
	tabWidth = "auto";
	boxWidth = "500px";
	}
else {
	tabWidth = (Number(fWidth) + 140) + "px";
	boxWidth = (Number(fWidth) + 240) + "px";
	}

document.getElementById("UCFTable").style.width = tabWidth;
document.getElementById("editbox").style.width = boxWidth;
}

// Event Notice scripts

function InsertToken (fieldName)
{
tokenmenu = document.getElementById("TokenMenu");
if (list.selectedIndex < 0) return;
token = tokenmenu.options[tokenmenu.selectedIndex].value;

var txtArea = document.getElementById(fieldName);
        
if (document.selection) {
	txtArea.focus();
	var sel = document.selection.createRange();
	sel.text = token;
	}
else if (txtArea.selectionStart || txtArea.selectionStart == '0') {
	var startPos = txtArea.selectionStart;
	var endPos = txtArea.selectionEnd;
	var scrollTop = txtArea.scrollTop;
	txtArea.value = txtArea.value.substring(0, startPos) + token + txtArea.value.substring(endPos, txtArea.value.length);
	txtArea.focus();
	txtArea.selectionStart = startPos + token.length;
	txtArea.selectionEnd = startPos + token.length;
	}
else {
	txtArea.value += textArea.value;
	txtArea.focus();
	}
}

// Activity Monitor scripts
var selTable;
var SelItem;

function LoadActivity ()
{
selTable = 0;
selItem = 0;
if (window.XMLHttpRequest) {
	req = new XMLHttpRequest();
	}
else if (window.ActiveXObject) {
	req = new ActiveXObject("Microsoft.XMLHTTP");
	}
if (req != undefined) {
	selAct = document.getElementById("activityopt");
	srch = "";
	if (selAct.selectedIndex == 1) {
		filterOpt = document.getElementById("recentfiletypes");
		if (filterOpt) srch = "?" + filterOpt.options[filterOpt.selectedIndex].value;
		}
	url = "/RAPR/" + encodeURI(selAct.options[selAct.selectedIndex].value) + ".html" + encodeURI(srch);
	req.onreadystatechange = function() { ActivityDone (); };
	req.open("GET", url, true);
	req.send("");
	document.getElementById("ActivitySessionListOptions").style.display='none';
	document.getElementById("RecentFilesListOptions").style.display='none';
	document.getElementById("DropShipmentsListOptions").style.display='none';
	document.getElementById("FileRequestsListOptions").style.display='none';
	document.getElementById("AccessURLsListOptions").style.display='none';
	}
}  

function ActivityDone ()
{
if (req.readyState == 4) {
	if (req.status == 200) {
		if (req.responseText == "login") window.location = "/";
		document.getElementById("activitydetail").innerHTML = req.responseText;
		switch (document.getElementById("activityopt").selectedIndex) {
			case 0: document.getElementById("ActivitySessionListOptions").style.display='block'; selTable=document.getElementById("activesessionbody"); break;
			case 1: document.getElementById("RecentFilesListOptions").style.display='block'; selTable=document.getElementById("recenttransfersbody"); break;
			case 2: document.getElementById("DropShipmentsListOptions").style.display='block'; selTable=document.getElementById("dropshipmentsbody"); break;
			case 3: document.getElementById("FileRequestsListOptions").style.display='block'; selTable=document.getElementById("filerequestsbody"); break;
			case 4: document.getElementById("AccessURLsListOptions").style.display='block'; selTable=document.getElementById("accessurlsbody"); break;
			}
		rows = selTable.getElementsByTagName("tr");
		for (i = 0; i < rows.length; i++) {
			rows[i].onclick = function() {SetSelection (this);return false;};
			rows[i].onmouseover = function() {if (this != selItem) this.style.background = "#C8D8E8";return false;};
			rows[i].onmouseout = function() {if (this != selItem) this.style.background = "#FFFFFF";return false;};
			}
		}
	else {
		document.getElementById("activitydetail").innerHTML="Failed to load activity detail form.";
		}
	}
}

function SetSelection (elem)
{
if (selTable) {
	rows = selTable.getElementsByTagName("tr");
	for (i = 0; i < rows.length; i++) rows[i].style.background="#FFFFFF";
	}
selItem = elem;
elem.style.background = "#A8B8C8";
}

function PerformActivityAction (cmd)
{
if (!selItem) {
	alert ("Please first select an item from the list.");
	return;
	}
if (window.XMLHttpRequest) {
	req = new XMLHttpRequest();
	}
else if (window.ActiveXObject) {
	req = new ActiveXObject("Microsoft.XMLHTTP");
	}
if (req != undefined) {
	url = "/RAPR/" + cmd + ".html" + "?" + selItem.id;
	req.onreadystatechange = function() { ActivityDone (); };
	req.open("GET", url, true);
	req.send("");
	}
}

function CloseMessage ()
{
document.getElementById("displayMessage").style.visibility="hidden";
}

// Define Users scripts

function GenRandPass ()
{
if (window.XMLHttpRequest) {
	req = new XMLHttpRequest();
	}
else if (window.ActiveXObject) {
	req = new ActiveXObject("Microsoft.XMLHTTP");
	}
if (req != undefined) {
	req.onreadystatechange = function() { GenPassDone(); };
	req.open("GET", "/RAPR/TriggerServerFunction.html?GeneratePassword", true);
	req.send("");
	}
}  

function GenPassDone ()
{
if (req.readyState == 4) {
	if (req.status == 200) {
		if (confirm ("The password generated is: " + req.responseText + "\n\nAssign this password?")) {
			document.forms["DefineUsers"].elements["Password"].value = req.responseText;
			}
		}
  	else {
		alert ("Failed to execute server function.");
		}
	}
}

function DisplayPassword ()
{
pass = document.forms["DefineUsers"].elements["Password"].value;

if (pass == "---------------") alert ("The user account password is encrypted and cannot be viewed or retrieved.");
else alert ("The user account password is: " + pass);
}

function SetHomeToRoot (isSuper)
{
if (isSuper) {
	if (confirm ("Are you sure you want to reset this user's Home Folder to the FTP Root folder?"))
		document.forms["DefineUsers"].elements["HomeFolder"].value = "ROOT";
	}
else {
	if (confirm ("Are you sure you want to reset this user's Home Folder to your top level folder?"))
		document.forms["DefineUsers"].elements["HomeFolder"].value = "";
	}
}

function SendLoginMail ()
{
document.getElementById("mailform").innerHTML = "Loading ...";
document.getElementById("sendmail").style.visibility = "visible";
if (window.XMLHttpRequest) {
	req = new XMLHttpRequest();
	}
else if (window.ActiveXObject) {
	req = new ActiveXObject("Microsoft.XMLHTTP");
	}
if (req != undefined) {
	url = "/RAPR/SendLoginDetailsEMail.html?" + encodeURI(document.getElementById("Username").value);
	req.onreadystatechange = function() { MailFormDone (); };
	req.open("GET", url, true);
	req.send("");
	}
}  

function MailFormDone ()
{
if (req.readyState == 4) {
	if (req.status == 200) {
		document.getElementById("mailform").innerHTML = req.responseText;
		mailAddr = document.getElementById("EMailAddress").value;
		if (mailAddr.length > 0) document.getElementById("MailTo").value = mailAddr;
		}
	else {
		document.getElementById("mailform").innerHTML="Failed to load mail form.";
		}
	}
}

function CancelMail (user)
{
document.getElementById("sendmail").style.visibility = "hidden";
}

function SendMailMessage ()
{
document.getElementById("SendFormEMail").submit();
}

function MailResult (msg)
{
alert (msg);
document.getElementById("sendmail").style.visibility = "hidden";
}


var foldlstReq = null;
var foldPathList = new Array();
var autoselectfolder = "";
var pathFieldToSet = null;

function OpenChooseFolder (f2s)
{
pathFieldToSet = f2s;

window.scrollTo(0,0);
document.getElementById("choosefolder").style.display="block";

if (window.ActiveXObject) foldlstReq=new ActiveXObject("Microsoft.XMLHTTP");
else foldlstReq=new XMLHttpRequest();
foldlstReq.onreadystatechange=setFolderPath;
theform = document.forms["DefineUsers"];
if (theform) foruser = theform.elements["Username"].value;
else foruser = "FTPROOT";
foldlstReq.open("GET", "/-?adminhomefolder-" + foruser, true);
foldlstReq.send(null);
}

function setFolderPath () 
{
if (foldlstReq.readyState == 4) {
	if (foldlstReq.status == 200) {
		foldPathList.length = 0;
		homefold = null;
		r1=foldlstReq.responseXML.getElementsByTagName("homef");
		if (r1) r2 = r1[0].firstChild;
		if (r2) homefold = r2.nodeValue;
		if (homefold == null) foldPathList.push ("");
		else {
			list = homefold.split("/");
			for (i = 0 ; i < list.length ; i++) foldPathList.push (list[i]);
			}
		foldlstReq=null;
		UpdateFoldersList ();
		}
	else {
		foldlstReq=null;
		}
	}
}

function UpdateFoldersList ()
{
list = document.getElementById("FolderPath");
list.options.length = 0;
for (i = 0 ; i < foldPathList.length ; i++)
	if (foldPathList[i] != "") list.options[i] = new Option(foldPathList[i], foldPathList[i]);
	else list.options[i] = new Option("Home", "Home");
list.selectedIndex = list.options.length-1;

document.getElementById('FolderOptions').options.length = 0;

thepath = "";
for (i = 0 ; i < foldPathList.length ; i++)
	if (foldPathList[i] != "") thepath = thepath + "/" + foldPathList[i];
if (thepath == "") thepath = "/-";

if (window.ActiveXObject) foldlstReq=new ActiveXObject("Microsoft.XMLHTTP");
else foldlstReq=new XMLHttpRequest();
foldlstReq.onreadystatechange=processFoldListChange;
foldlstReq.open("GET", encodeURI (thepath) + "?folderslist", true);
foldlstReq.send(null);
}

function processFoldListChange () 
{
selectedF = -1;

if (foldlstReq.readyState == 4) {
	if (foldlstReq.status == 200) {
		response=foldlstReq.responseXML.documentElement;
		list = document.getElementById('FolderOptions');
		list.options.length = 0;
		folders = response.getElementsByTagName("f");
		for (var i = 0 ; i < folders.length; i++) {
			list.options[list.options.length] = new Option(folders[i].firstChild.nodeValue, folders[i].firstChild.nodeValue);
			if (folders[i].firstChild.nodeValue == autoselectfolder) selectedF = i;
			}
		if (i >= 0) list.selectedIndex = selectedF;
		autoselectfolder = "";
		foldlstReq=null;
		list.focus();
		}
	else {
		foldlstReq=null;
		}
	}
}

function MoveToSubFolder ()
{
	list = document.getElementById("FolderOptions");
	if (list.selectedIndex < 0) return;
	foldPathList.push (list.options[list.selectedIndex].value);
	UpdateFoldersList ();
}

function MoveToParentFolder ()
{
	list = document.getElementById("FolderPath");
	if (list.selectedIndex < 0) return;
	remainingopts = list.selectedIndex + 1;
	while (foldPathList.length > remainingopts) foldPathList.pop ();
	UpdateFoldersList ();
}

function SelectFolder ()
{
	thepath = "";
	for (i = 0 ; i < foldPathList.length ; i++)
		if (foldPathList[i] != "") thepath = thepath + "/" + foldPathList[i];
	list = document.getElementById("FolderOptions");
	if (list.selectedIndex >= 0) thepath = thepath + "/" + list.options[list.selectedIndex].value;
	thepath = thepath + "/";
	if (pathFieldToSet) pathFieldToSet.value = thepath;
	document.getElementById("choosefolder").style.display="none";
}

function CancelSelectFolder ()
{
	document.getElementById("choosefolder").style.display="none";
}

function DisplayNewFolder ()
{
	nfa = document.getElementById("setnewfolder");
	if (nfa.style.display == "none") {
		nfa.style.display = "block";
		document.getElementById("NewFolder").focus();
		}
	else {
		nfa.style.display = "none";
		document.getElementById("is_selection").focus();
		}
}

function CreateNewFolder ()
{
	newfname = document.getElementById("NewFolder").value;
	if (newfname.length < 1) {
		alert ("Please first enter a name for the new folder.");
		return;
		}
	thepath = "";
	for (i = 0 ; i < foldPathList.length ; i++)
		if (foldPathList[i] != "") thepath = thepath + "/" + foldPathList[i];
	thepath = thepath + "/" + newfname;
	if (window.ActiveXObject) foldlstReq=new ActiveXObject("Microsoft.XMLHTTP");
	else foldlstReq=new XMLHttpRequest();
	foldlstReq.onreadystatechange=processFoldListChange;
	foldlstReq.open("GET", encodeURI(thepath) + "?createfolderinlist", true);
	foldlstReq.send(null);
	document.getElementById("setnewfolder").style.display = "none";
	autoselectfolder = newfname;
	document.getElementById("NewFolder").value = "";
}

function GetColumnWidths ()
{
if (window.XMLHttpRequest) {
	req = new XMLHttpRequest();
	}
else if (window.ActiveXObject) {
	req = new ActiveXObject("Microsoft.XMLHTTP");
	}
if (req != undefined) {
	req.onreadystatechange = function() { GetColumnWidthsDone(); };
	req.open("GET", "/RAPR/TriggerServerFunction.html?GetColumnWidths;;" + document.forms["WebSettings"].elements["SelectedDomain"].value, true);
	req.send("");
	}
}  

function GetColumnWidthsDone ()
{
if (req.readyState == 4) {
	if (req.status == 200) {
		widths = req.responseText.split (",");
		if (widths.length < 6) alert ("An error occurred while computing column widths.");
		else {
			document.forms["WebSettings"].elements["ColWidthOptsMenu"].value = widths[0];
			document.forms["WebSettings"].elements["ColWidthFileIcon"].value = widths[1];
			document.forms["WebSettings"].elements["ColWidthFilename"].value = widths[2];
			document.forms["WebSettings"].elements["ColWidthFileSize"].value = widths[3];
			document.forms["WebSettings"].elements["ColWidthLastMod"].value = widths[4];
			document.forms["WebSettings"].elements["ColWidthFileActions"].value = widths[5];
			}
		}
  	else {
		alert ("Failed to execute server function.");
		}
	}
}


function OpenHelp (page)
{
if (CurrentHelp != "")
	window.open("/RAPR/HelpPage"+CurrentHelp+".html","RumpusHelp","width=540,height=440,menubar=no,resizable=no,scrollbars=no,status=no,toolbar=no",false);
}


function FSAdd ()
{
i = 1;
while (document.getElementById("Set"+i)) {
	if (document.getElementById("Set"+i).style.display == 'none') {
		if (document.getElementById("Path"+i).value != '-') {
			document.getElementById("Set"+i).style.display = 'table';
			return;
			}
		}
	i++;
	}
alert ("To add more folders, please first save the changes you have made, then re-open the folder set.");
}


function FSRemove (id)
{
document.getElementById("Path"+id).value = '-';
document.getElementById("Set"+id).style.display = 'none';
}


function FSChoose (id)
{
OpenChooseFolder (document.getElementById("Path"+id));
}
