function setupHelp ()
{
var cg = null;
sf = document.getElementById("fieldSelect");
sflist = document.querySelectorAll(".HDB0");
for (i = 0 ; i < sflist.length ; i++) {
	oname = sflist[i].innerHTML;
	if (oname.charAt(0) == "-") {
		if (cg != null) sf.appendChild(cg);
		cg=document.createElement("optgroup");
		cg.label = oname.substring(1);
		}
	else {
		if (cg != null) {
			opt = document.createElement("option");
			opt.value = oname;
			opt.appendChild(document.createTextNode(oname));
			cg.appendChild(opt);
			}
		}
	}
if (cg != null) sf.appendChild(cg);
sf.selectedIndex = 0;
displayHelp ();
}


function displayHelp ()
{
sf = document.getElementById("fieldSelect");
opt = sf.selectedIndex;
db1 = document.querySelectorAll(".HDB1");
db2 = document.querySelectorAll(".HDB2");
db3 = document.querySelectorAll(".HDB3");
document.getElementById("Default").innerHTML = "Default Value: " + db1[opt].innerHTML;
document.getElementById("Tip").innerHTML = "<p>" + db2[opt].innerHTML + "</p>";
if (db3[opt].innerHTML.length < 3) document.getElementById("DescLabel").innerHTML = "";
else document.getElementById("DescLabel").innerHTML = "Description";
document.getElementById("Description").innerHTML = "<p>" + db3[opt].innerHTML + "</p>";
}