var appletouter = document.getElementById("appletouter");
html = appletouter.innerHTML;
html = html.substring( html.indexOf("<!--") + 4 );
html = html.substring(0, html.indexOf("-->") - 3);
appletouter.innerHTML = html;
